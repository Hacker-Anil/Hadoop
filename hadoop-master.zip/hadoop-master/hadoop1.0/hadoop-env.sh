export JAVA_HOME=/usr/java/jdk1.7.0_25/
export HADOOP_HOME=/home/hadoop/hadoop
export HADOOP_PID_DIR=/home/hadoop/pids
export HADOOP_HEAPSIZE=500
